# A sample script for high-temporal resolution (~1 hour) seismic velocity change (dv/v) measurement
Before you use the script, you need to change the path of each script

## Phase 1: Data PreProcess
Use the following scripts to pre-process your continuous data.
Please save the raw data in this type (ntnm.sntm.kzstarttimekz.channel.sac):
    rawdata/HN001/
    ├── 149
    │   │......
    │   ├── HN001.149.kz2021-08-14T00:27:50.748000Zkz.DPN.sac
    │   ├── HN001.149.kz2021-08-14T00:27:50.748000Zkz.DPE.sac
    │   ├── HN001.149.kz2021-08-14T00:27:50.748000Zkz.DPZ.sac
    │   │......

Remove the instrumental respones: Dvv_Demo_v1/Phase1_PreProcess/step01_transfer_sac.py


## Phase 2: Cal the Single-station Cross-correlation Function (SCF)
Use the following scripts to cal the SCF with your pre-processed continuous data

1. Cal the SCF: Dvv_Demo_v1/Phase2_SCFCal/step01_Scorr.jl
2. Obtain SCF from h5file and SVD Wiener Filter: Dvv_Demo_v1/Phase2_SCFCal/step02_SCF_Stack.py

## Phase 3: Measure the seismic velocity change with cross-wavelet transform method
Use the following scripts to cal the dv/v with the SCF you process in Phase 2

The script is based on the https://github.com/shujuanmao/cross-wavelet-transform?tab=readme-ov-file
you need to install the pycwt

1. Cal the frequency-dependent dv/v: Dvv_Demo_v1/Phase3_dvvCal/step01_WCS_measure.py
2. Cal the average dv/v: Dvv_Demo_v1/Phase3_dvvCal/step02_obtain_dvov.py