import os
from glob import glob
from os.path import join, basename
import numpy as np
import matplotlib.pyplot as plt


def obtain_dvv(dvv_file):
    dvov_dat = np.load(dvv_file)
    # print(dvov_dat)
    Dvv = dvov_dat['Dvv']
    Dvv_qcs = dvov_dat['Dvv_qcs']
    Dvv_error = dvov_dat['Dvv_error']
    freqs = dvov_dat['freqs']
    return Dvv, Dvv_qcs, freqs

def obtain_dvv_mean_xc(dvv_files):
    Dvv_xcs = []
    for dvv_file in dvv_files:
        Dvv, Dvv_qcs, freqs = obtain_dvv(dvv_file)
        Dvv[Dvv_qcs==False] = np.nan
        Dvv_xcs.append(Dvv)
    Dvv_xcs = np.array(Dvv_xcs)
    Mean_Dvv = np.nanmean(Dvv_xcs, axis=0)
    mean_dvv = np.nanmean(Mean_Dvv, axis=1)
    # print(len(Mean_Dvv), len(Mean_Dvv[0]))
    return Mean_Dvv, mean_dvv, freqs


dvv_dir = "../Demo_Data/scorr_dvv"


nets = glob(join(dvv_dir, "*"))
for net in nets[:]:
    ntnm = basename(net)
    stas = glob(join(net, "*"))
    for sta in stas[:]:
        stnm = basename(sta)
        print(stnm)
        dvv_files = glob(join(sta, 'Wiener*.npz'))
        Mean_Dvv, mean_dvv, freqs = obtain_dvv_mean_xc(dvv_files)
        print(len(Mean_Dvv))
        Mean_Dvv_T = np.transpose(Mean_Dvv)

        dvov_file = f"{ntnm}.{stnm}.dvov.npz"
        np.savez(join(dvv_dir, ntnm, stnm, dvov_file), Mean_Dvv=Mean_Dvv_T, mean_dvv=mean_dvv, freqs=freqs)