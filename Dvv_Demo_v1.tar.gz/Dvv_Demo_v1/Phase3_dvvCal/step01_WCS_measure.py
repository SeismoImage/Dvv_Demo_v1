from xwt import xwt
from os.path import join, basename
import numpy as np
from glob import glob
import matplotlib.pyplot as plt
from copy import deepcopy
from scipy.optimize import curve_fit
import os

# from noisepy.seis.noise_module import wct_modified as wcsa
def linear_dvov(x, a, b):
    return a * x + b


def dvov_dit(time, WXdt, Weight):
    qcs = []
    for i in range(len(Weight)):
        Zero, None_zero = 0, 0
        for j in range(len(Weight[i])):
            if Weight[i][j] == 0:
                Zero += 1
            else:
                None_zero += 1
        None_Zero_Rate = (None_zero/(Zero + None_zero)) * 100
        if None_Zero_Rate > 25:
            qcs.append(True)
        else:
            qcs.append(False)
    dvovs = []
    dvovs_error = []
    for i in range(len(WXdt)):
        popt, pcov = curve_fit(linear_dvov, time, WXdt[i])
        dvov = popt[0]
        error = pcov
        dvovs.append(dvov)
        dvovs_error.append(error)
    dvovs = np.array(dvovs)
    dvovs_error = np.array(dvovs_error)
    return dvovs, dvovs_error, qcs

def dvov_measure(WXamp, Wcoh, WXdt, time):
    Weight = []
    for i in range(len(WXamp)):
        Sub_WXamp = np.abs(WXamp[i])
        Sub_WXamp /= np.max(Sub_WXamp)
        Weight.append(Sub_WXamp)
    Weight = np.array(Weight)
    # Define the Weight

    # Seletc the coherence and max dt

    Weight[Wcoh<0.8] = 0
    Weight[np.abs(WXdt)>0.3] = 0
    Weight_WXdt = WXdt * Weight
    # Zero_Value = 0
    # Total_Value = 0
    # for i in range(len(Weight)):
    #     for j in range(len(Weight)):
    #         if Weight[i][j] == 0:
    #             Zero_Value += 1
    #         Total_Value += 1

    # Weight_Rate = Zero_Value/Total_Value
    # if (1-Weight_Rate) * 100 < 25:
    #     print("These Measure is Useless")
    #     qc = False
    # else:
    #     qc = True
    dvovs, dvovs_errro, qcs = dvov_dit(time, Weight_WXdt, Weight)
    return dvovs, dvovs_errro, qcs


scf_dir = "../Demo_Data/scorr_npz"
out_dir = "../Demo_Data/scorr_dvv"
scf_files = glob(join(scf_dir, "*"))

#
fs, ns, nt, vpo, freqmin, freqmax, nptsfreq = 50, 3, 0.25, 10, 2, 10, 100


for scf_file in scf_files:
    ntnm, stnm = basename(scf_file).split('.')[0], basename(scf_file).split('.')[1]
    os.makedirs(join(out_dir, ntnm, stnm), exist_ok=True)
    print("-"*10)
    print(f"{ntnm} {stnm} Begin!")
    scf_data = np.load(scf_file)

    # en = scf_data['Wiener_en']
    lag_time = np.linspace(-20, 20, 2001)
    # trace_ref = en.mean(axis=0)

    # prefix = ['en_neg.npz', 'en_pos.npz', 'ez_neg.npz', 'ez_pos.npz', 'nz_neg.npz', 'nz_pos.npz']

    scs = ['Wiener_en', 'Wiener_ez', 'Wiener_nz']

    # Coda wave window
    time_combs = [[-10, -2], [2, 10]]
    causal_part = ['neg', 'pos']
    Dvv_xcs = []
    QC_xcs = []
    for sc in scs:
        scf = scf_data[sc]
        trace_ref = scf.mean(axis=0)
        for t, time_comb in enumerate(time_combs):
            t1, t2 = time_comb[0], time_comb[1]
            Dvv_freq_hour = []
            QC = []
            WXamps, Wcohs, WXdts = [], [], []
            for k in range(len(scf)):
                trace_current = scf[k]
                lag_ind = (lag_time >= t1) & (lag_time <= t2)
                WXamp, WXspec, WXangle, Wcoh, WXdt, freqs, coi = xwt(trace_ref[lag_ind], trace_current[lag_ind], fs, ns, nt, vpo, freqmin, freqmax, nptsfreq)
                WXamps.append(WXamp)
                Wcohs.append(Wcoh)
                WXdts.append(WXdt)

            Dvv, Dvv_error, Dvv_qcs = [], [], []
            for i in range(len(WXamps)):
                dvovs, dvovs_errro, qcs = dvov_measure(WXamps[i], Wcohs[i], WXdts[i], lag_time[lag_ind])
                Dvv.append(dvovs)
                Dvv_error.append(dvovs_errro)
                Dvv_qcs.append(qcs)
                        
            dvov_file = f"{sc}.{causal_part[t]}"
            np.savez(join(out_dir, ntnm, stnm, dvov_file), Dvv=Dvv, Dvv_error=Dvv_error, Dvv_qcs=Dvv_qcs, freqs=freqs)
    print(f"{ntnm} {stnm} Over!")
    print("-"*10)
    