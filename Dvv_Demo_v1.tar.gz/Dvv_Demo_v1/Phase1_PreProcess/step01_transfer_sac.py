import os
from glob import glob
from os.path import join, basename
import numpy as np
import obspy
import subprocess

raw_dir = "../Demo_Data/rawdata"
pz_dir = "../stats/PZ"
out_dir = "../Demo_Data/hourlydata"

nets = glob(join(raw_dir, '*'))
for net in nets[:]:
    ntnm = basename(net)
    stas = glob(join(net, '*'))
    for sta in stas[:]:
        stnm = basename(sta)
        os.makedirs(join(out_dir, ntnm, stnm), exist_ok=True)
        channels = ["DPE", "DPN", "DPZ"]
        for channel in channels:
            pz_file = f"{channel}.PZ"
            sacfiles = glob(join(sta, f"*{channel}*"))
            for sacfile in sacfiles:
                tr = obspy.read(sacfile)[0]
                tr.resample(50)
                tr.write(sacfile, format="SAC")
                s = ""
                s += "r {}\n".format(sacfile)
                # s += "rmean;rtr;taper\n"
                # s += "decimate 5\n"
                s += "rmean;rtr;taper\n"
                s += "trans from polezero subtype {} to vel freq 0.001 0.002 20 22\n".format(join(pz_dir, pz_file))
                s += "mul 1.0e9\n"
                s += "w {}\n".format(join(out_dir, ntnm, stnm, basename(sacfile)))
                s += "q\n"
                subprocess.Popen(['sac'], stdin=subprocess.PIPE).communicate(s.encode())
            print("{} Over".format(channel))
            