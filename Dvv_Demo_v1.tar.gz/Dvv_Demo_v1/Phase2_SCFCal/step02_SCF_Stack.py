import os
from glob import glob
from os.path import join, basename
import numpy as np
from obspy import UTCDateTime
import h5py
from scipy.linalg import svd
from scipy.signal import wiener

def wiener_filter(scf, SVD_N):
    U, S, V = svd(scf)
    C = np.zeros((len(U), len(V)))

    for i in range(SVD_N):
        si = S[i]
        ui = U[:, i].reshape(-1, 1)
        vi = V[i, :].reshape(1, -1)

        sub_C = si * np.dot(ui, vi)
        sub_C_filtered = wiener(sub_C, (3, 3))

        C += sub_C_filtered
    C = wiener(C, (3, 3))
    return C

def get_SCF(sta):
    en, ez, nz = [], [], []
    Dates = []
    h5files = glob(join(sta, "*"))
    for h5file in h5files:
        prefix = basename(h5file).split('.')
        date_id = prefix[2].split('kz')[1]

        scf = h5py.File(h5file, "r")
        sub_en = scf['Csub_en'][:].mean(axis=0)
        sub_ez = scf['Csub_ez'][:].mean(axis=0)
        sub_nz = scf['Csub_nz'][:].mean(axis=0)
        # print(sub_en)
        en.append(sub_en)
        ez.append(sub_ez)
        nz.append(sub_nz)
        Dates.append(date_id)
        print(date_id)
    return en, ez, nz, Dates


scorr_dir = "../Demo_Data/scorr"
out_dir = "../Demo_Data/scorr_npz"

nets = glob(join(scorr_dir, "*"))
for net in nets[:]:
    ntnm = basename(net)
    stas = glob(join(net, "*"))
    for sta in stas[:]:
        stnm = basename(sta)
        en, ez, nz, Dates = get_SCF(sta)
        # print(en)
        Wiener_en = wiener_filter(en, SVD_N=10)
        Wiener_ez = wiener_filter(ez, SVD_N=10)
        Wiener_nz = wiener_filter(nz, SVD_N=10)
        npz_file = f"{ntnm}.{stnm}.npz"
        np.savez(join(out_dir, npz_file), en=en, ez=ez, nz=nz, Dates=Dates, Wiener_ez=Wiener_ez, Wiener_en=Wiener_en, Wiener_nz=Wiener_nz)